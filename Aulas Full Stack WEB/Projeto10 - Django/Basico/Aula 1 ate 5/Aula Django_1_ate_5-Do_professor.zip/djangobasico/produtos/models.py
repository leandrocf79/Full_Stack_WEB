from django.db import models
"""
modelos de dados, para salvar em um banco de dados 
ou utilizar na aplicação
"""
# Create your models here.

