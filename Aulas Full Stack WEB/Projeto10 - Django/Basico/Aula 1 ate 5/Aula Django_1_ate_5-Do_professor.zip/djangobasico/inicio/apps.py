from django.apps import AppConfig


class InicioConfig(AppConfig):
    name = 'inicio'
