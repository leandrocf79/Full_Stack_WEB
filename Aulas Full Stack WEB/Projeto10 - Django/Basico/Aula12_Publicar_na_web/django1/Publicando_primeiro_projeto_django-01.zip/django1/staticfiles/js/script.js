function teste(){
    alert("Funciona mesmo!");
}