from django.apps import AppConfig


class SiteFinansConfig(AppConfig):
    name = 'site_finans'
